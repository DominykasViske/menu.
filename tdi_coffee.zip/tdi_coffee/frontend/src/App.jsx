import React, { useState } from 'react';

// Coffee product data (10 items)
const coffeeProducts = [
  {
    id: 1,
    name: '5 lb Coffee Bag Colombia Decaf',
    price: '€86,00',
    imageUrl: 'path/to/image1.jpg',
  },
  {
    id: 2,
    name: 'Bulk Whole Bean Coffee (5lb Bag)',
    price: '€74,00',
    imageUrl: 'path/to/image2.jpg',
  },
  {
    id: 3,
    name: 'Custom Branded Coffee Bags',
    price: '€12,95',
    imageUrl: 'path/to/image3.jpg',
  },
  {
    id: 4,
    name: 'Colombia Single Origin Farm Select',
    price: '€15',
    imageUrl: 'path/to/image4.jpg',
  },
  {
    id: 5,
    name: 'Calma Decaf',
    price: '€17,50',
    imageUrl: 'path/to/image5.jpg',
  },
  {
    id: 6,
    name: 'Decaf',
    price: '€18,00',
    imageUrl: 'path/to/image6.jpg',
  },
  {
    id: 7,
    name: 'Viking Blends',
    price: '€17,50',
    imageUrl: 'path/to/image7.jpg',
  },
  {
    id: 8,
    name: 'Woods Blends',
    price: '€17,50',
    imageUrl: 'path/to/image8.jpg',
  },
  {
    id: 9,
    name: '2 Bags Donut Joe’s Christmas Blend Coffee',
    price: '€35,00',
    imageUrl: 'path/to/image9.jpg',
  },
  {
    id: 10,
    name: '2024 Christmas Coffee Advent Calendar - 24 Full-Pot Bags of Flavored Ground Coffee',
    price: '€65,00',
    imageUrl: 'path/to/image10.jpg',
  },
];

// Tea product data (5 items)
const teaProducts = [
  {
    id: 11,
    name: 'Collection - 45 count, 15 flavors',
    price: '€22,00',
    imageUrl: 'path/to/tea1.jpg',
  },
  {
    id: 12,
    name: 'Tea Bag Collection',
    price: '€19,00',
    imageUrl: 'path/to/tea2.jpg',
  },
  {
    id: 13,
    name: 'Yorkshire Tea Bags – 3.25kg',
    price: '€33,00',
    imageUrl: 'path/to/tea3.jpg',
  },
  {
    id: 14,
    name: 'Premium Green Tea',
    price: '€4,00',
    imageUrl: 'path/to/tea4.jpg',
  },
  {
    id: 15,
    name: 'PG Tips Original Tea Bags',
    price: '€40',
    imageUrl: 'path/to/tea5.jpg',
  },
];

// Souvenir product data (5 items)
const souvenirs = [
  {
    id: 16,
    name: 'Souvenir Cold Cup',
    price: '€6,00',
    imageUrl: 'path/to/souvenir1.jpg',
  },
  {
    id: 17,
    name: 'Porcelain espresso cup depicting the Parthenon of Athens, accompanied by a blue spoon, a great souvenir from Greece.',
    price: '€6,00',
    imageUrl: 'path/to/souvenir2.jpg',
  },
  {
    id: 18,
    name: 'Alaska 3D Medallion Mug – Reactive Glaze',
    price: '€17,00',
    imageUrl: 'path/to/souvenir3.jpg',
  },
  {
    id: 19,
    name: 'Arizona Copper Medallion Green Mug',
    price: '€17,00',
    imageUrl: 'path/to/souvenir4.jpg',
  },
  {
    id: 20,
    name: 'Arizona Watercolor Mug',
    price: '€12,00',
    imageUrl: 'path/to/souvenir5.jpg',
  },
];

// Product Card Component
const ProductCard = ({ product }) => (
  <div className="bg-white p-5 rounded-lg shadow-lg hover:shadow-xl transition duration-300 transform hover:scale-105">
    <img
      src={product.imageUrl}
      alt={product.name}
      className="h-48 w-full object-cover rounded-t-lg"
    />
    <div className="pt-5">
      <h2 className="text-xl font-bold text-gray-900 truncate">{product.name}</h2>
      <p className="text-lg text-gray-700 mt-2">{product.price}</p>
    </div>
    <button className="mt-6 w-full bg-gradient-to-r from-yellow-400 to-yellow-600 text-white py-2 rounded-lg font-bold hover:from-yellow-500 hover:to-yellow-700 transition duration-200">
      Add to Cart
    </button>
  </div>
);

// Product Grid Component
const ProductGrid = ({ products }) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
    {products.map((product) => (
      <ProductCard key={product.id} product={product} />
    ))}
  </div>
);

// Main App Component
const App = () => {
  const [currentCategory, setCurrentCategory] = useState('coffee'); // State to manage category

  // Function to switch between categories
  const getProducts = () => {
    if (currentCategory === 'coffee') {
      return coffeeProducts;
    } else if (currentCategory === 'tea') {
      return teaProducts;
    } else {
      return souvenirs;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white py-8 shadow-md">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl font-extrabold text-gray-800 text-center">
            {currentCategory === 'coffee' && 'Our Organic Coffee Products'}
            {currentCategory === 'tea' && 'Our Organic Tea Selection'}
            {currentCategory === 'souvenirs' && 'Our Souvenirs'}
          </h1>
        </div>
      </header>

      <main className="container mx-auto px-6 py-12">
        {/* Centered Buttons at the top */}
        <div className="flex justify-center mb-8 space-x-4">
          <button
            onClick={() => setCurrentCategory('coffee')}
            className={`px-6 py-3 bg-blue-500 text-white font-bold rounded-lg hover:bg-blue-600 transition duration-200 ${currentCategory === 'coffee' && 'bg-blue-700'}`}
          >
            Coffee Products
          </button>
          <button
            onClick={() => setCurrentCategory('tea')}
            className={`px-6 py-3 bg-green-500 text-white font-bold rounded-lg hover:bg-green-600 transition duration-200 ${currentCategory === 'tea' && 'bg-green-700'}`}
          >
            Tea Selection
          </button>
          <button
            onClick={() => setCurrentCategory('souvenirs')}
            className={`px-6 py-3 bg-yellow-500 text-white font-bold rounded-lg hover:bg-yellow-600 transition duration-200 ${currentCategory === 'souvenirs' && 'bg-yellow-700'}`}
          >
            Souvenirs
          </button>
        </div>

        {/* Product Grid */}
        <ProductGrid products={getProducts()} />
      </main>
    </div>
  );
};

export default App;